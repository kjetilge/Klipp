Template.video.onCreated(function () {
  Meteor.subscribe("videos");
})

Template.video.events({
  'click button.snapshot': function (e, t) {
    console.log("snap")
    video = t.find('video')
    captureStill()
    console.log(video.currentTime)
  },
  'click button.splash-shot': function (e, t) {
    var video_id="123"
    video = t.find('video')
    time = video.currentTime
    console.log(video.currentTime)
    Meteor.call('makeSplash', video_id, time)
  }
})

function captureStill() {
  var video = $("video").get(0);
  var canvas = document.createElement("canvas");
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext('2d')
        .drawImage(video, 0, 0, canvas.width, canvas.height);

  var img = document.createElement("img");
  img.src = canvas.toDataURL();
  Images.insert(canvas.toDataURL())
}

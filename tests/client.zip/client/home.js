Template.images.images = function() {
	return Images.find();
};
